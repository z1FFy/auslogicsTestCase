<?php
/**
 * App index file
 *
 * @author Denis Kuschenko <ziffyweb@gmail.com>
 */

require_once ('app/core/functions.php');
require_once ('app/core/BaseController.php');

require_once ('app/routing.php');