<html>
<head>
    <title>Tables</title>
</head>
<style>
    .wrapper {
        width:70%;
        margin: 0 auto;
    }

    .block {
        display: inline-block;
        width: 50%;
        height: auto;
        text-align: center;
    }
    .block div {
        margin: 10px;
        padding: 10px;
        background-color: #eee;
    }

    header, footer {
        width: 100%;
        height: 200px;
        background-color: #eee;
        box-shadow: inset 0 0 0px 10px #fff;
    }


</style>
<body>
<div class="wrapper">
    <header></header>
        <div class="block">
            <div>Text text Text text Text text Text text
                Text text Text text Text text Text text Text text Text text Text text Text text Text text Text text Text text Text text <br>Text text Text text Text text Text text <br>
                Text text Text text Text text Text text <br>
                Text text Text text Text text Text text <br>   Text text Text text Text text Text text <br>Text text Text text Text text Text text <br>
                Text text Text text Text text Text text <br>
                Text text Text text Text text Text text <br>
                </div>
        </div><div class="block">
            <div>
            Text text Text text Text text Text text <br>
            </div>
        </div>


    <footer></footer>
</div>
</body>
</html>